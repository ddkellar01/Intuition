# Intuition — Deconstructed Structure

Every file in the project, what it is, and what it does.
Verified against the code and Darion's supplied sources on 2026-10-28:
13 experts, 161 merged files, 8 devices, shown-price total $1,002.97,
62 pytest passing, smoke green.

## Root

- `.dockerignore` — what Docker leaves out of the build context (git files, caches, tests, docs).
- `.gitignore` — what git leaves untracked (bytecode caches, build output, pytest cache).
- `Dockerfile` — multi-stage image build: installs the package in a builder, ships it on a slim runtime as a non-root user, entrypoint is the `intuition` command.
- `README.md` — project front page: what Intuition is, quickstart commands, structure.
- `docker-compose.yml` — runs Intuition plus the 4 merged credkellar images (deconstruction, malware-sandbox-suite, app-data-compressor, honeyroot-x) behind the `fleet` profile; passes an optional GEMINI_API_KEY.
- `pyproject.toml` — package definition: name `intuition`, version 0.1.0, the `intuition` console command, src layout, no dependencies (pure stdlib).

## Workflows — `.github/workflows/`

- `ci.yml` — CI on every push and pull request: install the package, run the 62 tests, run the smoke script.
- `docker-publish.yml` — publishes the image straight to Docker Hub (login + build-push actions, no GHCR, no script) on pushes to main, `v*` tags, or manual run; tags `:latest` and `:<commit sha>`. Needs the DOCKERHUB_USERNAME / DOCKERHUB_TOKEN repo secrets.

## Docs — `docs/`

- `COUNCIL.md` — how the council works: ask one expert, ask each, ask routed, the grand answer.
- `HARDWARE.md` — the full hardware table: all 8 devices with sources and prices exactly as shown.
- `MERGE_MAP.md` — how the 13 supplied source trees map into this package.
- `SOURCES_AS_SUPPLIED.md` — honesty flags on the sources: one note's title (ChatGPT/OpenAI) does not match its root (gemini-4-frontier); two filenames appear in two trees as supplied; 3 filenames illegible in the video were omitted, not invented.
- `STRUCTURE.md` — this file: the whole project deconstructed, with a description for every file.

## Scripts — `scripts/`

- `smoke.py` — end-to-end smoke test: list experts, ask one, ask each (13 answers), grand answer, then the hardware checks (8 devices, camera capture, EEG mode, voice brief, projection brief, lie-detector flags). Prints SMOKE GREEN when all of it works.

## The package — `src/intuition/`

### Entry points

- `__init__.py` — package entry: exports `Intuition` plus the registry helpers (`list_sources`, `get_source`, `total_files`, `docker_images`).
- `__main__.py` — makes `python -m intuition` run the command line.
- `cli.py` — the command line itself: `list`, `files <expert>`, `ask`, `ask-all`, `route`, `grand` (with `--report` / `--json`), `hardware [device]`, `voice`, `project`, `stats`, `docker`.

### The council core

- `asi.py` — ASI, the top layer: the `Intuition` class. Routes a question, asks one expert, asks each expert, or produces the grand answer. Adds no facts of its own.
- `council.py` — the Council: ask one expert by id, ask every expert, or ask the routed top 3.
- `experts.py` — one Expert per merged source. An expert answers only from its own files and cites the file each fact came from.
- `grand.py` — the Grand Answer: facts from all 13 experts ranked by confidence, consensus concepts (surfaced by 2+ experts), unique insights (one expert only), and a mean confidence. Nothing is added that no expert said.
- `registry.py` — registry of the 13 merged sources: lookup by id, file counts, the 4 merged Docker images, and the routing examples derived from the sources.
- `sources_data.py` — the data, not logic: all 13 sources and their 161 file entries, transcribed from Darion's video notes with the descriptions the notes gave them.
- `report.py` — markdown report builder for grand answers (synthesis section plus every expert in full).

### The AI stack (ASI / NNL / LLM / ML / SML / LML)

- `router.py` — the Router: decides which expert(s) should answer, combining LML relevance, SML kNN votes, and NNL MLP probabilities through the ML ensemble.
- `ml.py` — ML ensemble: fixed routing weights (LML .50, SML .30, NNL .20) and the confidence score (logistic squash of retrieval strength).
- `sml.py` — SML (small ML): a kNN router over labelled example texts, plus the logistic function used for confidence.
- `nnl.py` — NNL (neural layer): a small multi-layer perceptron with backpropagation, pure stdlib, trained on the sources' own file descriptions to predict which expert a question belongs to. Training accuracy 0.741.
- `lml.py` — LML (local models): one TF-IDF model per expert, built only from that expert's own files — this is what makes "ask each" mean something.
- `llm.py` — LLM layer: composes an expert's answer only from the facts its local model retrieved, with citations; never invents a file. If GEMINI_API_KEY is set, an optional polish pass rewrites the grounded draft without adding facts.
- `text.py` — text utilities used by every layer: tokenizing with light stemming/aliases, TF-IDF vectors, cosine similarity.

### The hardware layer (added 2026-10-28, as supplied)

- `hardware.py` — the device registry: all 8 devices/concepts with their specs, sources, and prices recorded only where Darion's screenshots showed them.
- `camera.py` — the 8K cinematic camera, the eyes of Intuition: see (live feed frame), take pics (stills kept as cited evidence, `cam-0001` style ids), record (8K sessions). Captures can be asked about through the council.
- `drone.py` — flying-disc drone control: hand gestures map to council commands — push = next expert, pull = previous expert, hold = grand answer, flip = re-route the question, wave = stop.
- `eeg.py` — EEG headband adapter: band powers (Delta, Theta, Alpha, Beta, Gamma, SMR) become focus and relaxation scores and an answer mode — full, standard, or brief. A UX signal, not a medical reading.
- `lie_detector.py` — polygraph-style sensor: skin conductance (GSR), heart rate, and respiration compared against the subject's own baseline produce a stress index (weights .50 / .30 / .20) and a follow-up flag with a suggested follow-up question. It measures arousal, not deception — it never outputs a truth/lie verdict.
- `projection.py` — the projection brief: a grand answer compressed to at most 9 large lines for the Kodak projector / holographic display.
- `voice.py` — Voice Mode: turns a grand answer into a short spoken brief (top facts, consensus, confidence) and runs voice sessions against the council.

### The 8 devices in `hardware.py` (double-checked against the supplied sources)

- `quest_pro` — Meta Quest Pro, the mixed-reality council interface. $799.99 as shown (-20%, list $999.99), 256GB / 12GB, rated 3.8 (778). Source: Amazon screen video.
- `kodak_projector` — Kodak Ultra Mini Portable Projector, shared-room output for grand answers. HD 1080p, LED DLP, up to 100 inch, Silver, rated 4.0 (2,951). No price was visible in the screenshot — none recorded. Source: Amazon screenshot.
- `flying_drones` — hand-operated flying-disc drones, gesture input. All 3 listings from the search screenshot: $22.99, 4.3 (696); $16.99, 3.8 (230); Force1 Scoot, 4.0 (11.8K), price cut off — none recorded for it. Source: Amazon search screenshot.
- `eeg_headband` — EEG Neurofeedback Headband (SereniBrain / iHANK), brainwave context input. $179.99 as shown (-10%), Dark Grey, rated 4.0 (115), band ratios Delta/Theta/Alpha/Beta/Gamma/SMR, score example 86. Source: Amazon screenshot.
- `voice_mode` — Voice Mode UI, the voice-first interface. Design reference from Darion's concept image — not a product, no price.
- `holo_projector` — Holographic Assistant Projector, hologram display target for the projection brief. Design reference from Darion's concept image — not a product, no price.
- `camera_8k` — 8K Cinematic Camera, the eyes: see, take pics, record. Added by Darion in chat — no brand or price supplied, none invented.
- `lie_detector` — Lie Detector Sensor: GSR + heart rate + respiration vs baseline. Added by Darion in chat — no brand or price supplied, none invented.

Known shown-price total: $1,002.97 (Quest Pro $799.99 + EEG headband $179.99 + first drone $22.99). Everything without a visible price is excluded, not zero-filled.

## Tests — `tests/`

- `test_intuition.py` — 39 tests for the council: the merge (13 sources, 161 files, 4 Docker images), ask-each citation checks per expert, routing top-1 cases, NNL learning, grand-answer structure and grounding, and the CLI.
- `test_hardware.py` — 23 tests for the hardware layer: all 8 devices included, prices exactly as shown (and None where not shown), EEG modes, camera modes and citations, drone gestures, voice/projection briefs, lie-detector flags (including that it never claims deception), and the hardware CLI.
